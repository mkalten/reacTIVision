

//	this is the only class you should need to explicitly instantiate!
#import <VVUVCKit/VVUVCController.h>
